﻿namespace Invoices
{
    using AutoMapper;

    using Data.Models;
    using DataProcessor.ImportDto;
    using DataProcessor.ExportDto;

    public class InvoicesProfile : Profile
    {
        public InvoicesProfile()
        {
            // Address
            this.CreateMap<ImportAddressDto, Address>();
            // Client
            this.CreateMap<ImportClientDto, Client>();
            this.CreateMap<Client, ExportClientDto>();
            // Invoice
            this.CreateMap<ImportInvoiceDto, Invoice>();
            // Product
            this.CreateMap<ImportProductDto, Product>();
            this.CreateMap<Product, ExportProductsWithMostClientDto>()
                .ForMember(d => d.Name, opt => opt.MapFrom(s=> s.Name))
                .ForMember(d => d.Price, opt => opt.MapFrom(s => s.Price))
                .ForMember(d => d.CategoryType, opt => opt.MapFrom(s => s.CategoryType))
                .ForMember(d => d.Clients, opt => opt.MapFrom(s => s.ProductsClients
                    .Where(pc => pc.Client.Name.Length >= 11)
                    .Select(pc => pc.Client)
                    .OrderBy(c => c.Name)
                    .ToArray()));
        }
    }
}
