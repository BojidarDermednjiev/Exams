﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=ADMINISTRATOR\SQLEXPRESS;Database=Invoices;Integrated Security=True;Encrypt=False";
    }
}
