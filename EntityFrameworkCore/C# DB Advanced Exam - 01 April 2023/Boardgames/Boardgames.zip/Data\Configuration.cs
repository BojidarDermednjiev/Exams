﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=ADMINISTRATOR\SQLEXPRESS;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
