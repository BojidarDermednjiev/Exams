const BASE_URL = "http://localhost:3030/jsonstore/tasks/";
let vacations = {};
const inputSelectors = {
  name: document.getElementById("name"),
  days: document.getElementById("num-days"),
  date: document.getElementById("from-date"),
};
const otherSelectors = {
  list: document.getElementById("list"),
};
const actionBtn = {
  loadBtn: document.getElementById("load-vacations"),
  addBtn: document.getElementById("add-vacation"),
  editBtn: document.getElementById("edit-vacation"),
};
actionBtn.editBtn.addEventListener("click", editVacation);
actionBtn.loadBtn.addEventListener("click", loadVacations);
actionBtn.addBtn.addEventListener("click", addVacation);

function loadVacations() {
  otherSelectors.list.innerHTML = "";
  fetch(BASE_URL)
    .then((res) => res.json())
    .then((vacationsRes) => {
      const currVacations = Object.values(vacationsRes);
      vacations = currVacations;

      for (const { _id, name, days, date } of currVacations) {
        const divApplication = createElement(
          "div",
          otherSelectors.list,
          null,
          ["container"],
          _id
        );
        createElement("h2", divApplication, name);
        createElement("h3", divApplication, date);
        createElement("h3", divApplication, days);

        const changeBtn = createElement("button", divApplication, "Change", [
          "change-btn",
        ]);
        changeBtn.addEventListener("click", changeVacation);

        const doneBtn = createElement("button", divApplication, "Done", [
          "done-btn",
        ]);
        doneBtn.addEventListener("click", doneVacation);

        otherSelectors.list.appendChild(divApplication);
      }
    });
}
function addVacation(event) {
  if (event) {
    event.preventDefault();
  }

  const httpHeaders = {
    method: "POST",
    body: JSON.stringify({
      name: inputSelectors.name.value,
      days: inputSelectors.days.value,
      date: inputSelectors.date.value,
    }),
  };
  fetch(`${BASE_URL}`, httpHeaders)
    .then(loadVacations())
    .catch((err) => console.error(err));

  Object.values(inputSelectors).forEach((input) => (input.value = ""));
}
function editVacation(event) {
  if (event) {
    event.preventDefault();
  }
  const id = event.currentTarget.getAttribute("_id");
  console.log(event.currentTarget);
  const httpHeaders = {
    method: "PUT",
    body: JSON.stringify({
      name: inputSelectors.name.value,
      days: inputSelectors.days.value,
      date: inputSelectors.date.value,
      _id: id,
    }),
  };

  fetch(`${BASE_URL}${id}`, httpHeaders)
    .then(loadVacations())
    .catch((err) => console.error(err));

  actionBtn.editBtn.disabled = true;
  actionBtn.addBtn.disabled = false;
}
function changeVacation(event) {
  const id = event.currentTarget.parentNode.id;

  const currentVacation = vacations.find((x) => x._id == id);
  Object.keys(inputSelectors).forEach((key) => {
    inputSelectors[key].value = currentVacation[key];
  });

  event.currentTarget.parentNode.remove();
  vacations.splice(vacations.indexOf(currentVacation), 1);
  actionBtn.editBtn.setAttribute("_id", id);
  actionBtn.addBtn.disabled = true;
  actionBtn.editBtn.disabled = false;
}
function doneVacation(event) {
  if (event) {
    event.preventDefault();
  }
  const vacationToRemove = event.currentTarget.parentNode;
  console.log(vacationToRemove);

  const httpHeaders = {
    method: "DELETE",
  };

  fetch(`${BASE_URL}${vacationToRemove.id}`, httpHeaders)
    .then(loadVacations())
    .catch((err) => console.error(err));
}
function createElement(
  type,
  parentNode,
  content,
  classes,
  id,
  attributes,
  useInnerHtml
) {
  const htmlElement = document.createElement(type);

  if (content && useInnerHtml) {
    htmlElement.innerHTML = content;
  } else if (content && type !== "input") {
    htmlElement.textContent = content;
  }

  if (content && type === "input") {
    htmlElement.value = content;
  }

  if (classes && classes.length > 0) {
    htmlElement.classList.add(...classes);
  }

  if (id) {
    htmlElement.id = id;
  }

  if (attributes) {
    for (const attribute in attributes) {
      htmlElement.setAttribute(attribute, attributes[attribute]);
    }
  }

  if (parentNode) {
    parentNode.appendChild(htmlElement);
  }

  return htmlElement;
}
